from django.shortcuts import render, redirect
from django.views import View
from . import models, forms
import datetime
from django.utils import timezone
import re, random
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ObjectDoesNotExist


# global userz
# userz=None

class Home(View):
	def get(self, request):
		global userz
		if("logout" in request.GET):
			del request.session['userz']
			return redirect("/")
		elif ("login" in request.GET):	
			return redirect("Login")
		else: 
			qs1=models.Questions.objects.all()
			userz = None
			if(request.session.get('userz')):
				userz = request.session['userz']
			dict1={"k1":qs1, 'cu':userz}
			print('created by utkarsh sharma')
			return render(request, "home.html", dict1)
			
	def post(self, request):
		global userz
		print(request.POST)
		if ("askQ" in request.POST):
			if(not(request.session.get('userz'))):
				return redirect("Login")
			else:
				return redirect("Ask")
		if ("search" in request.POST):
			print('searching...')
			temp = request.POST['asked']
			temp=temp.strip()
			if(temp==''):
				return redirect("Home")
			qs1=models.Questions.objects.all()
			qs2 = qs1.filter(title__contains = temp)
			if(len(qs2)==0):
				qs2 = None
			userz = None
			if(request.session.get('userz')):
				userz = request.session['userz']
			dict1={"k1":qs2, 'cu':userz}
			return render(request, "threadz.html", dict1)
		if ("back" in request.POST):
			return redirect("Home")

			
class Ask(View):
	def get(self, request):
		if("logout" in request.GET):
			del request.session['userz']
			return redirect("/")
		elif ("login" in request.GET):	
			return redirect("Login")
		elif(not(request.session.get('userz'))):
			return render(request,"login.html")
		else:
			qs1=models.Questions.objects.all()
			userz = None
			if(request.session.get('userz')):
				userz = request.session['userz']
			dict1={"k1":qs1, 'cu':userz}
			return render(request, "ask.html", dict1)
			print('Made by Utkarsh Sharma')
	def post(self, request):
		global userz
		if ("postQ" in request.POST):
			if(not(request.session.get('userz'))):
				return render(request,"login.html")
			else:
				ob = models.Questions()
				title = request.POST['title']
				title=title.strip()
				if(title ==''):
					return redirect("Home")
				body = request.POST['body']
				now = datetime.datetime.now()
				dateAsked = now.strftime("%m/%d/%Y, %H:%M:%S")
				userz = str(request.session['userz'])
				userOb = models.CustomUsers.objects.get(name = userz)
				ob= models.Questions(title=title, body=body, dateAsked=now, askedBy=userOb)
				try:
					ob.save()
				except:
					return redirect("Home")
				all = models.Questions.objects.all()
				userz = None
				if(request.session.get('userz')):
					userz = request.session['userz']
				dict1={'k1':all, 'cu':userz}
				print('\n created by Utkarsh')
				return redirect("Home")
		if ("cancel" in request.POST):
			return redirect("Home")

class Question(View):
	def get(self, request, questionId):
		global userz	
		if("logout" in request.GET):
			del request.session['userz']
			return redirect("/")
		elif ("login" in request.GET):	
			return redirect("Login")
		else: 
			ob = models.Questions.objects.get(pk=questionId)
			ans = models.Ans()
			
			try:
				ans = models.Ans.objects.filter(questionId=questionId).order_by('-upvotez')
			except(ObjectDoesNotExist):
				pass
			except:
				pass
			ansList=[]

			if ("None" in str(ans)):
				ans=None
				ansList=None
			elif(len(ans)==0):
				ans=None
				ansList=None
			elif(len(ans)==1):
				for i in ans:
					ansList.append(i)
			elif(len(ans)>1):
				for i in ans:
					ansList.append(i)
				ans=None
			oblist = []
			if (ansList is not None):
				for ans in ansList:
					commentQs = models.Comment.objects.filter(ans=ans).order_by('dateCommented')
					if (len(commentQs)>0):
						comm=[]	
						for j in commentQs:
							comm.append(j)
					else:
						comm=None
					
					dispans = forms.dispAns()
					dispans.comments = comm
					dispans.ans = ans
					oblist.append(dispans)
			userz = None
			if(request.session.get('userz')):
				userz = request.session['userz']
			d1={"q": ob, 'rm':ansList, 'cu':userz, 'said': oblist} 	
			print('created by utkarsh sharma')
			return render(request, "questionAns.html", d1)
		
	def post(self, request, questionId):

		global userz
		if ("postA" in request.POST):
			if(not(request.session.get('userz'))):
				return redirect("Login")
			else:
				return redirect("reply",  questionId)
		if ("home" in request.POST):
			return redirect("Home")
			
		if ("commented" in request.POST):
			if(not(request.session.get('userz'))):
				return redirect("Login")
			else:
				commentBody = request.POST['commentBody']
				ansId = request.POST['aId']
				ans = models.Ans.objects.get(pk=ansId)
				userz = str(request.session['userz'])
				userOb = models.CustomUsers.objects.get(name = userz)
				now = datetime.datetime.now()
				comment = models.Comment(commentBody = commentBody, commentBy=userOb, dateCommented = now, ans=ans)
				comment.save()
				Question().get(self, request, questionId) 

class postcomment(View):
	def get(self, request, ansId):
		global userz
		if("logout" in request.GET):
			del request.session['userz']
			return redirect("/")
		elif ("login" in request.GET):	
			return redirect("Login")
		elif(not(request.session.get('userz'))):
			return redirect("Login")
		else:
			ans = models.Ans.objects.get(pk=ansId)
			question = models.Questions.objects.get(pk=ans.questionId)
			userz = None
			if(request.session.get('userz')):
				userz = request.session['userz']
			d11={'q':question , 'r':ans, 'cu':userz}
			return render(request, "postcomment.html", d11)
			
	def post(self, request, ansId):
		if("postComm"  in request.POST):
			global userz
			if(not(request.session.get('userz'))):
				return redirect("Login")
			else:
				commentBody = request.POST['commentBody']
				ans = models.Ans.objects.get(pk=ansId)
				commentBody=commentBody.strip()
				if(commentBody ==''):
					return redirect("Question", ans.questionId)
				userz = str(request.session['userz'])
				userOb = models.CustomUsers.objects.get(name = userz)
				now = datetime.datetime.now()
				comment = models.Comment(commentBody = commentBody, commentBy=userOb, dateCommented = now, ans=ans)
				comment.save()
				q1=Question()
				temp=ans.questionId
				return redirect("Question",  ans.questionId)
				
		if("cancel"  in request.POST):
			ans = models.Ans.objects.get(pk=ansId)
			return redirect("Question",  ans.questionId)

class LikedAns(View):
	def get(self, request, ansId):
		if(not(request.session.get('userz'))):
			return redirect("Login")
		else:
			userz = str(request.session['userz'])
			userOb = models.CustomUsers.objects.get(name = userz)
			ans = models.Ans.objects.get(pk=ansId)		
			likes=models.Likes()
			likes.ans=ans
			likes.likedBy=userOb
			
			try:
				likes.save()
				ans = models.Ans.objects.get(pk=ansId)
				ans.upvotez=ans.upvotez+1
				ans.save()
			except:
				pass
			finally:				
				return redirect("Question",  ans.questionId)
				
				
class Login(View):
	def get(self, request):
		return render(request,"login.html")
		
	def post(self, request):
		global userz
		if ("login" in request.POST):
			userz = None
			users = models.CustomUsers()
			email = request.POST['user']
			pswd = request.POST['code']
			try:
				users = models.CustomUsers.objects.get(email=email)
			except:
				msg = {'message': 'Incorrect Email-Id'}
				return render(request,"login.html", msg)
			# currentUser= {'cu':userz}
			if(pswd==users.pswd):
				request.session['userz'] = users.name
				userz = request.session['userz']
				currentUser= {'cu':userz}
				return redirect("Home")
			else:
				msg = {'message' : 'Incorrect Password'}
				return render(request,"login.html")
		if ("cancel" in request.POST):
			return redirect("Home")
		if ("cancelSgn" in request.POST):
			msg = {'message': None}
			return render(request,"login.html", msg)
		if ("sgnUp" in request.POST):
			if(request.session.get('userz')):
				del request.session['userz']
			users = models.CustomUsers()
			name = request.POST['name'].strip()
			email = request.POST['email'].strip()
			pswd = request.POST['pswd1']
			if(name=='' or email=='' or pswd==''):
				return redirect("Login")
			users = models.CustomUsers(name=name, email=email, pswd=pswd)
			try:
				users.save()
				request.session['userz'] = users.name
				userz = request.session['userz']
				currentUser= {'cu':userz}
			except:
				msg = {'message': 'Invalid Details Entered or Email-ID already registered'}
				return render(request,"login.html", msg)
			return redirect("Home")			
			
def reply(request, questionId):
	global userz
	if(request.method!="POST"):
		if("logout" in request.GET):
			del request.session['userz']
			return redirect("/")
		elif("login" in request.GET):	
			return redirect("Login")
		elif(not(request.session.get('userz'))):
			return redirect("Login")
		question=models.Questions.objects.get(pk=questionId)
		userz = str(request.session['userz'])
		dict1={"q":question, 'cu':userz}
		return render(request,"reply.html", dict1)

	if(request.method=="POST"):
		if ("postA" in request.POST):
			ans = models.Ans()
			body = request.POST['body']
			body=body.strip()
			if(body==''):
				return redirect("Question", questionId)
			now = datetime.datetime.now()
			dateAns = now.strftime("%m/%d/%Y, %H:%M:%S")
			qs=models.Questions.objects.get(pk=questionId)
			question = (models.Questions)(qs)
			ans.body=body
			ans.dateAns=now
			userz = str(request.session['userz'])
			userOb = models.CustomUsers.objects.get(name = userz)
			ans.ansBy=userOb
			ans.questionId = questionId
			ans.save() 
			return redirect("Question", questionId)
		if ("cancel" in request.POST):		
			return redirect("Question", questionId)
							