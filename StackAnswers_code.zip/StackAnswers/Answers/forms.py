from django import forms
from . import models


class SgnUpForm(forms.ModelForm):
	password = forms.CharField(widget=forms.PasswordInput)
	class Meta:
		model = models.CustomUsers
		fields = ('name', 'email')
		
class LoginForm(forms.ModelForm):
	password = forms.CharField(widget=forms.PasswordInput)
	class Meta:
		model = models.CustomUsers
		fields = ('email',)
		
class dispAns:
	ans = models.Ans()
	comments = []