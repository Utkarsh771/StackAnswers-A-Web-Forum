from django.contrib import admin

# Register your models here.

from . import models
admin.site.register(models.CustomUsers)
admin.site.register(models.Questions)
admin.site.register(models.Ans)
admin.site.register(models.Likes)