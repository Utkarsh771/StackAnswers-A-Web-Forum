from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User

class CustomUsers(models.Model):
	name = models.CharField(max_length=32, unique=True)
	email = models.EmailField(unique=True, help_text='h111')
	pswd = models.CharField(max_length=32, help_text='Incorrect Password')
	
class Questions(models.Model):
	title=models.CharField(max_length=100,help_text='question cannot be empty', unique=True)
	body=models.TextField(blank=True)
	dateAsked = models.DateTimeField(default=timezone.now,blank=True)
	askedBy = models.ForeignKey(to=CustomUsers, on_delete=models.SET_NULL, null=True, default=None)
	
class Ans(models.Model):
	body=models.TextField(blank=True,help_text='answer cannot be empty')
	dateAns = models.DateTimeField(default=timezone.now,blank=True)
	ansBy = models.ForeignKey(to=CustomUsers, on_delete=models.SET_NULL, null=True, default=None)
	questionId = models.IntegerField(blank=True, null=True, default=None, unique=False)
	upvotez = models.IntegerField(default=0)	
	
class Likes(models.Model):
	ans= models.ForeignKey(to=Ans, on_delete=models.CASCADE, default=None)
	likedBy= models.ForeignKey(to=CustomUsers, on_delete=models.CASCADE, default=None)
	class Meta:
		unique_together = (("ans", "likedBy"),)
		
class Comment(models.Model):
	commentBody = models.TextField(max_length=100, default=None, help_text='answer cannot be empty')
	ans = models.ForeignKey(to=Ans, on_delete=models.CASCADE, default=None)
	commentBy = models.ForeignKey(to=CustomUsers, on_delete=models.CASCADE, null=True, default=None)
	dateCommented = models.DateTimeField(default=timezone.now,blank=True)