from django.urls import path, include
from . import views
from django.contrib.auth import views as defaultViews



urlpatterns = [
	path('', views.Home.as_view(), name='Home'),
	path('ask/', views.Ask.as_view(), name='Ask'),
	path('login/', views.Login.as_view(), name='Login'),
	path("question/<int:questionId>/", views.Question.as_view(), name="Question"),
	path("answer/<int:questionId>/", views.reply, name="reply"),
	path("answerlike/<int:ansId>/", views.LikedAns.as_view(), name="LikedAns"),
	path("postcomment/<int:ansId>/", views.postcomment.as_view(), name="postcomment"),
	# path("commentAns2/<int:ansId>/", views.commentAns2.as_view(), name="commentAns2"),
	# path("answer/<list:qaId>/<int:ansId>/", views.LikedAns.as_view(), name="LikedAns"),
]