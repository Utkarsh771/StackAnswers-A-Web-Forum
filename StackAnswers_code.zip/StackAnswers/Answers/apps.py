from django.apps import AppConfig


class AnswersConfig(AppConfig):
    name = 'Answers'
